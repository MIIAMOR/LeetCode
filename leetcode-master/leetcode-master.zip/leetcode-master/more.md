# 持续更新中

为什么刷题：https://leetcode.wang/leetcode100%E6%96%A9%E5%9B%9E%E9%A1%BE.html

知乎开设了专栏，同步更新：[https://zhuanlan.zhihu.com/leetcode1024](https://zhuanlan.zhihu.com/leetcode1024)，关注后可以及时收到更新，网站有时候可能出问题打不开，建议关注一下知乎专栏备用。

准备刷一道，总结一道，目前事情比较多，更新频率会低一些，感谢支持。

300 题以后的打算，参考 <a href="leetcode力扣刷题1到300的感受.html">leetcode 力扣刷题 1 到 300 的感受</a>。

可以加好友一起交流

微信： 17771420231

公众号： windliang，更新编程相关